// // ignore_for_file: non_constant_identifier_names

// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:get_storage/get_storage.dart';
// import 'package:flutter_dotenv/flutter_dotenv.dart';
// import 'package:firebase_core/firebase_core.dart';
// import 'package:showcaseview/showcaseview.dart';



// void main() async {
//   WidgetsFlutterBinding.ensureInitialized();
//   await LocalNotificationService().notificationInitialized();
//   await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
//   await GetStorage.init();
//   await dotenv.load(fileName: ".env");
//   runApp(MyApp());
// }

// // muvi_colorPrimary
// //  enableInteractiveSelection: false,
// // ignore: must_be_immutable
// class MyApp extends StatelessWidget {
//   GetStorage AsyncStorage = GetStorage();

//   _getThemeStatus() async {
//     // Get.changeThemeMode(_isLightTheme.value ? ThemeMode.light : ThemeMode.dark);
//     if (AsyncStorage.hasData('isDarkTheme')) {
//       bool isDarkTheme = AsyncStorage.read('isDarkTheme');
//       if (isDarkTheme) {
//         Get.changeTheme(Themes.themedark);
//       } else {
//         Get.changeTheme(Themes.themelight);
//       }
//     }
//   }

//   MyApp({Key? key}) : super(key: key) {
//     _getThemeStatus();
//     FirebaseMessagingService(LocalNotificationService()).initialize();
//   }
//   // const MyApp({Key? key}) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     Get.put(DeepLinkController(context: context));
//     Get.put(CheckConnectionStream(context: context));

//     String pageRoute;

//     if (AsyncStorage.hasData('profile')) {
//       pageRoute = "/DashBoard";
//     } else {
//       pageRoute = "/";
//     }

//     return ShowCaseWidget(
//       onStart: (index, key) {},
//       onComplete: (index, key) {},
//       blurValue: 1,
//       builder: Builder(
//           builder: (context) => GetMaterialApp(
//                 title: "soksok",
//                 debugShowCheckedModeBanner: false,
//                 initialRoute: '/Login',
//                 translations: Messages(),
//                 locale: const Locale('fa', 'IR'),
//                 fallbackLocale: const Locale('fa', 'IR'),
//                 theme: Themes.themelight,
//                 darkTheme: Themes.themedark,
//                 themeMode: ThemeMode.dark,
//                 textDirection: TextDirection.rtl,
//                 getPages: [
//                   GetPage(
//                     name: '/',
//                   ),
         
//                 ],
//               )),
//     );
//   }
// }
