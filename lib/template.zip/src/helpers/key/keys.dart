// import 'package:flutter_dotenv/flutter_dotenv.dart';

// final String base_url_Request = dotenv.get('BASE_URL');
// final String base_url_image_static = dotenv.get('BASE_URL_IMAGE_STATIC');
