// ignore_for_file: file_names, non_constant_identifier_names

import 'dart:convert';

import 'package:client_information/client_information.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:navid_utils/utils/device_info/device_info.dart';

final base_url = dotenv.get('BASE_URL');

GetStorage AsyncStorage = GetStorage();

getHttp(url) async {
  try {
    Map<String, String> headers = await headerRequest();
    final Url = Uri.parse("$base_url/$url");
    var response = await http.get(
      Url,
      headers: headers,
    );

    int responseCode = response.statusCode;
    if (responseCode > 199 && responseCode <= 299) {
      return response;
    } else {
      String msg = '';
      try {
        msg = jsonDecode(response.body)['message'].toString();

        if (msg == 'Unauthorized') {
          bool isRefreshCompleted = await refreshToken();
          if (isRefreshCompleted) {
            return getHttp(url);
          } else {
            Get.offAllNamed('/');
          }
        } else {
          return ResponseCustom(
              body: jsonEncode({
            "message": msg,
            "success": false,
            "responseCode": responseCode,
            "urlRequest": '$base_url/$url',
            "username": usernameProfile()
          }));
        }
      } catch (e) {
        msg = '';
        return ResponseCustom(
            body: jsonEncode({
          "message": msg,
          "success": false,
          "responseCode": responseCode,
          "urlRequest": '$base_url/$url',
          "username": usernameProfile()
        }));
      }
    }
  } catch (e) {
    return ResponseCustom(
        body: jsonEncode({
      "message": "catch --$e",
      "success": false,
      "responseCode": 151515115,
      "urlRequest": '$base_url/$url',
      "username": usernameProfile()
    }));
  }
}

getHttpCustomUrl(url) async {
  try {
    final Url = Uri.parse('$url');
    Map<String, String> headers = await headerRequest();
    var response = await http.get(
      Url,
      headers: headers,
    );
    int responseCode = response.statusCode;
    if (responseCode > 199 && responseCode <= 299) {
      return response;
    } else {
      String msg = '';
      try {
        msg = jsonDecode(response.body)['message'].toString();
        if (msg == 'Unauthorized') {
          bool isRefreshCompleted = await refreshToken();
          if (isRefreshCompleted) {
            return getHttpCustomUrl(url);
          } else {
            Get.offAllNamed('/');
          }
        } else {
          return ResponseCustom(
              body: jsonEncode({
            "message": msg,
            "success": false,
            "responseCode": responseCode,
            "urlRequest": '$url',
            "username": usernameProfile()
          }));
        }
      } catch (e) {
        msg = '';
        return ResponseCustom(
            body: jsonEncode({
          "message": msg,
          "success": false,
          "responseCode": responseCode,
          "urlRequest": '$url',
          "username": usernameProfile()
        }));
      }
    }
  } catch (e) {
    return ResponseCustom(
        body: jsonEncode({
      "message": "catch --$e",
      "success": false,
      "responseCode": 151515115,
      "urlRequest": '$url',
      "username": usernameProfile()
    }));
  }
}

deleteHttp(url, body) async {
  try {
    final Url = Uri.parse("$base_url/$url");
    Map<String, String> headers = await headerRequest();
    var response = await http.delete(
      Url,
      body: body,
      headers: headers,
    );
    int responseCode = response.statusCode;
    if (responseCode > 199 && responseCode <= 299) {
      return response;
    } else {
      String msg = '';
      try {
        msg = jsonDecode(response.body)['message'].toString();
        if (msg == 'Unauthorized') {
          bool isRefreshCompleted = await refreshToken();
          if (isRefreshCompleted) {
            return deleteHttp(url, body);
          } else {
            Get.offAllNamed('/');
          }
        } else {
          return ResponseCustom(
              body: jsonEncode({
            "message": msg,
            "success": false,
            "responseCode": responseCode,
            "urlRequest": '$url',
            "username": usernameProfile()
          }));
        }
      } catch (e) {
        msg = '';
        return ResponseCustom(
            body: jsonEncode({
          "message": msg,
          "success": false,
          "responseCode": responseCode,
          "urlRequest": '$url',
          "username": usernameProfile()
        }));
      }
    }
  } catch (e) {
    return ResponseCustom(
        body: jsonEncode({
      "message": "catch --$e",
      "success": false,
      "responseCode": 151515115,
      "urlRequest": '$url',
      "username": usernameProfile()
    }));
  }
}

postHttp(url, body) async {
  var URL = Uri.parse("$base_url/$url");
  Map<String, String> headers = await headerRequest();
  try {
    var response = await http.post(
      URL,
      body: body,
      headers: headers,
    );
    int responseCode = response.statusCode;
    if (responseCode > 199 && responseCode <= 299) {
      return response;
    } else {
      String msg = '';
      try {
        msg = jsonDecode(response.body)['message'].toString();
        if (msg == 'Unauthorized') {
          bool isRefreshCompleted = await refreshToken();
          if (isRefreshCompleted) {
            return postHttp(url, body);
          } else {
            Get.offAllNamed('/');
          }
        } else {
          return ResponseCustom(
              body: jsonEncode({
            "message": msg,
            "success": false,
            "responseCode": responseCode,
            "urlRequest": '$url',
            "username": usernameProfile()
          }));
        }
      } catch (e) {
        msg = '';
        return ResponseCustom(
            body: jsonEncode({
          "message": msg,
          "success": false,
          "responseCode": responseCode,
          "urlRequest": '$url',
          "username": usernameProfile()
        }));
      }
    }
  } catch (e) {
    return ResponseCustom(
        body: jsonEncode({
      "message": "catch --$e",
      "success": false,
      "responseCode": 151515115,
      "urlRequest": '$url',
      "username": usernameProfile()
    }));
  }
}

patchHttp(url, body) async {
  var URL = Uri.parse("$base_url/$url");
  Map<String, String> headers = await headerRequest();

  try {
    var response = await http.patch(
      URL,
      body: body,
      headers: headers,
    );
    int responseCode = response.statusCode;
    if (responseCode > 199 && responseCode <= 299) {
      return response;
    } else {
      String msg = '';
      try {
        msg = jsonDecode(response.body)['message'].toString();

        if (msg == 'Unauthorized') {
          bool isRefreshCompleted = await refreshToken();
          if (isRefreshCompleted) {
            return patchHttp(url, body);
          } else {
            Get.offAllNamed('/');
          }
        } else {
          return ResponseCustom(
              body: jsonEncode({
            "message": msg,
            "success": false,
            "responseCode": responseCode,
            "urlRequest": '$url',
            "username": usernameProfile()
          }));
        }
      } catch (e) {
        msg = '';
        return ResponseCustom(
            body: jsonEncode({
          "message": msg,
          "success": false,
          "responseCode": responseCode,
          "urlRequest": '$url',
          "username": usernameProfile()
        }));
      }
    }
  } catch (e) {
    return ResponseCustom(
        body: jsonEncode({
      "message": "catch --$e",
      "success": false,
      "responseCode": 151515115,
      "urlRequest": '$url',
      "username": usernameProfile()
    }));
  }
}

patchHttpCustom(url, body) async {
  var URL = Uri.parse(url);

  Map<String, String> headers = await headerRequest();

  try {
    var response = await http.patch(
      URL,
      body: body,
      headers: headers,
    );
    int responseCode = response.statusCode;
    if (responseCode > 199 && responseCode <= 299) {
      return response;
    } else {
      String msg = '';
      try {
        msg = jsonDecode(response.body)['message'].toString();
        if (msg == 'Unauthorized') {
          bool isRefreshCompleted = await refreshToken();
          if (isRefreshCompleted) {
            return patchHttpCustom(url, body);
          } else {
            Get.offAllNamed('/');
          }
        } else {
          return ResponseCustom(
              body: jsonEncode({
            "message": msg,
            "success": false,
            "responseCode": responseCode,
            "urlRequest": '$url',
            "username": usernameProfile()
          }));
        }
      } catch (e) {
        msg = '';
        return ResponseCustom(
            body: jsonEncode({
          "message": msg,
          "success": false,
          "responseCode": responseCode,
          "urlRequest": '$url',
          "username": usernameProfile()
        }));
      }
    }
  } catch (e) {
    return ResponseCustom(
        body: jsonEncode({
      "message": "catch --$e",
      "success": false,
      "responseCode": 151515115,
      "urlRequest": '$url',
    }));
  }
}

postHttpWithoutToken(url, body) async {
  var URL = Uri.parse("$base_url/$url");
  try {
    var response = await http.post(
      URL,
      body: body,
    );
    int responseCode = response.statusCode;
    if (responseCode > 199 && responseCode <= 299) {
      return response;
    } else {
      String msg = '';
      try {
        msg = jsonDecode(response.body)['message'].toString();
        if (msg == 'Unauthorized') {
          bool isRefreshCompleted = await refreshToken();
          if (isRefreshCompleted) {
            return postHttpWithoutToken(url, body);
          } else {
            Get.offAllNamed('/');
          }
        } else {
          return ResponseCustom(
              body: jsonEncode({
            "message": msg,
            "success": false,
            "responseCode": responseCode,
            "urlRequest": '$url',
            "username": usernameProfile()
          }));
        }
      } catch (e) {
        msg = '';
        return ResponseCustom(
            body: jsonEncode({
          "message": msg,
          "success": false,
          "responseCode": responseCode,
          "urlRequest": '$url',
          "username": usernameProfile()
        }));
      }
    }
  } catch (e) {
    return ResponseCustom(
        body: jsonEncode({
      "message": "catch --$e",
      "success": false,
      "responseCode": 151515115,
      "urlRequest": '$url',
      "username": usernameProfile()
    }));
  }
}

postHttpCustom(url, body, {bool reqByToken = true}) async {
  var URL = Uri.parse(url);

  Map<String, String> headers = await headerRequest();

  try {
    var response = await http.post(
      URL,
      body: body,
      headers: headers,
    );
    int responseCode = response.statusCode;
    if (responseCode > 199 && responseCode <= 299) {
      return response;
    } else {
      String msg = '';
      try {
        msg = jsonDecode(response.body)['message'].toString();
        if (msg == 'Unauthorized') {
          bool isRefreshCompleted = await refreshToken();
          if (isRefreshCompleted) {
            return postHttpCustom(url, body);
          } else {
            Get.offAllNamed('/');
          }
        } else {
          return ResponseCustom(
              body: jsonEncode({
            "message": msg,
            "success": false,
            "responseCode": responseCode,
            "urlRequest": '$url',
            "username": usernameProfile()
          }));
        }
      } catch (e) {
        msg = '';
        return ResponseCustom(
            body: jsonEncode({
          "message": msg,
          "success": false,
          "responseCode": responseCode,
          "urlRequest": '$url',
          "username": usernameProfile()
        }));
      }
    }
  } catch (e) {
    return ResponseCustom(
        body: jsonEncode({
      "message": "catch => $e",
      "success": false,
      "responseCode": 151515115,
      "urlRequest": '$url',
      "username": usernameProfile()
    }));
  }
}

Future<bool> refreshToken() async {
  ClientInformation info = await getDeviceInfo();

  var URL = Uri.parse('$base_url/auth/refresh-token');
  var response = await http.post(
    URL,
    body: jsonEncode({
      "device_id": info.deviceId,
      "refreshToken": jsonDecode(AsyncStorage.read("profile"))['refreshToken']
    }),
  );
  final decodedResponse = jsonDecode(response.body);
  if (decodedResponse['success']) {
    var newAccessToken = decodedResponse['accessToken'];
    var newRefreshToken = decodedResponse['refreshToken'];

    //
    Map myProfile = jsonDecode(AsyncStorage.read("profile"));

    AsyncStorage.write(
        "profile",
        jsonEncode({
          "mobile": myProfile['mobile'],
          "username": myProfile['username'],
          "first_name": myProfile['first_name'],
          "last_name": myProfile['last_name'],
          "accessToken": newAccessToken,
          "refreshToken": newRefreshToken
        }));

    return true;
  } else {
    return false;
  }
}

String usernameProfile() {
  if (AsyncStorage.hasData('profile')) {
    return jsonDecode(AsyncStorage.read('profile'))['username'];
  } else {
    return 'not have profile yet ';
  }
}

Future<Map<String, String>> headerRequest() async {
  ClientInformation info = await getDeviceInfo();
  if (kIsWeb) {
    try {
      if (AsyncStorage.hasData('profile')) {
        return <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
          'Authorization':
              jsonDecode(AsyncStorage.read("profile"))['accessToken'],
          'device-id': info.deviceId,
        };
      } else {
        return <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
          'device-id': info.deviceId,
        };
      }
    } catch (e) {
      return <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
        'device-id': 'web',
      };
    }
  } else {
    try {
      if (AsyncStorage.hasData('profile')) {
        return <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
          'Authorization':
              jsonDecode(AsyncStorage.read("profile"))['accessToken'],
          'device-id': info.deviceId
        };
      } else {
        return <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
          'device-id': info.deviceId
        };
      }
    } catch (e) {
      return <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
        'device-id': 'web'
      };
    }
  }
}

class ResponseCustom {
  late String body;

  ResponseCustom({required this.body});

  ResponseCustom.fromJson(Map<String, dynamic> json) {
    body = json['body'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['body'] = body;

    return data;
  }
}
