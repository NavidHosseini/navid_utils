import 'dart:async';
import 'dart:convert';

import 'package:client_information/client_information.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;
import 'package:navid_utils/utils/device_info/device_info.dart';
import 'package:uni_links/uni_links.dart';

class DeepLinkController extends GetxController {
  final base_url = dotenv.get('BASE_URL');
  GetStorage AsyncStorage = GetStorage();

  late BuildContext context;
  DeepLinkController({required this.context});
  Uri? _latestUri;
  Object? _err;
  late StreamSubscription _sub;

  Future<void> initUniLinks() async {
    _sub = uriLinkStream.listen((Uri? link) {
      _latestUri = link;
      final queryParams = _latestUri?.queryParametersAll.entries.toList();
      print('queryParams $queryParams');
      onMessage("");
      // if (queryParams!.isNotEmpty) {
      //   onMessagePremium(queryParams[0].value[0].toString());
      // }
    }, onError: (err) {
      // Handle exception by warning the user their action did not succeed
    });

    // NOTE: Don't forget to call _sub.cancel() in dispose()
  }

  onMessage(String data) async {}

  @override
  void onInit() {
    super.onInit();
    initUniLinks();
  }

  @override
  void onClose() {
    _sub.cancel();
    super.onClose();
  }
}
