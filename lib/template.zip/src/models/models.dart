class FAQ {
  String? title;
  String? subTitle;
  bool? isExpanded = false;

  FAQ({this.title, this.subTitle, this.isExpanded});
}
