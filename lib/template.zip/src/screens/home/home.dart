import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:navid_utils/src/screens/home/HomeController.dart';

class Home extends GetView<HomeController> {
  const Home({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        padding: EdgeInsets.all(20),
        child: Text("controller"), // just call `controller.something`
      ),
    );
  }
}
