// import 'package:intl/intl.dart' as intl;
// import 'dart:math';

// var f = intl.NumberFormat('###.000#', 'en_US');

// maskPrice(String price) {
//   if (price != 'null') {
//     var data = double.parse(price);
//     if (data > 100) {
//       var newData =
//           intl.NumberFormat.currency(customPattern: "###", locale: "en_US")
//               .format(data)
//               .split('.')[0];

//       return int.parse(newData);
//     } else {
//       return roundDouble(data, 4);
//       // return price.toString();
//     }
//   } else {
//     return 0.0;
//   }
// }

// maskPercent(percent) {
//   if (percent != 'null') {
//     var data = double.parse(percent);

//     if (data > 100) {
//       var newData =
//           intl.NumberFormat.currency(customPattern: ",###", locale: "en_US")
//               .format(data)
//               .split('.')[0];
//       return newData;
//     } else {
//       return roundDouble(data, 2);
//       // return price.toString();
//     }
//   } else {
//     return 'NaN';
//   }
// }

// double roundDouble(double value, int places) {
//   num mod = pow(10.0, places);
//   return ((value * mod).round().toDouble() / mod);
// }

// maskComma(String price) {
//   if (price != 'null') {
//     var data = double.parse(price);
//     if (data > 100) {
//       var newData =
//           intl.NumberFormat.currency(customPattern: ",###", locale: "en_US")
//               .format(data)
//               .split('.')[0];

//       return newData;
//     } else {
//       return roundDouble(data, 4);
//       // return price.toString();
//     }
//   } else {
//     return 0.0;
//   }
// }
