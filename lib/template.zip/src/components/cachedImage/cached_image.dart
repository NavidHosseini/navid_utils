import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:navid_utils/utils/loading/loading.dart';

Widget CachedImage(String imageUrl) {
  return ClipOval(
    child: CachedNetworkImage(
      imageUrl: imageUrl,
      fit: BoxFit.fill,
      placeholder: (context, url) =>
          const CustomLoading(height: 40.0, radius: 40.0),
      colorBlendMode: BlendMode.colorBurn,
      color: Colors.white,
      errorWidget: (context, url, error) {
        return Image.asset('assets/images/noImage.png');
      },
    ),
  );
}
